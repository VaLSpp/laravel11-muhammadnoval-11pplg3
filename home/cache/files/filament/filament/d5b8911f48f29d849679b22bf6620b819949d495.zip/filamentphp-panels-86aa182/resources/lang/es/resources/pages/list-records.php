<?php

return [

    'breadcrumb' => 'Listado',

];

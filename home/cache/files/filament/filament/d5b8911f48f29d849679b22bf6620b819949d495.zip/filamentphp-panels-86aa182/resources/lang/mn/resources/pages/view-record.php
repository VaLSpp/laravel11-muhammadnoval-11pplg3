<?php

return [

    'title' => 'Үзэх :label',

    'breadcrumb' => 'Үзэх',

    'content' => [

        'tab' => [
            'label' => 'Үзэх',
        ],

    ],

];

<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Sauvegarder',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Sauvegardé',
        ],

    ],

];

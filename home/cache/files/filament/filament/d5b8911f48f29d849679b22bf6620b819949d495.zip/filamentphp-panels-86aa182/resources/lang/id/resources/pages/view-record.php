<?php

return [

    'title' => 'Lihat :label',

    'breadcrumb' => 'Lihat',

    'content' => [

        'tab' => [
            'label' => 'Lihat',
        ],

    ],

];

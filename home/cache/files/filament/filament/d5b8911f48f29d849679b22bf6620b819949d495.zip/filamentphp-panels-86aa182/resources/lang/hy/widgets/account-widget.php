<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Դուրս գալ',
        ],

    ],

    'welcome' => 'Բարի գալուստ',

];

<?php

return [

    'title' => 'Nástěnka',

    'actions' => [

        'filter' => [

            'label' => 'Filtr',

            'modal' => [

                'heading' => 'Filtr',

                'actions' => [

                    'apply' => [

                        'label' => 'Použít',

                    ],

                ],

            ],

        ],

    ],

];

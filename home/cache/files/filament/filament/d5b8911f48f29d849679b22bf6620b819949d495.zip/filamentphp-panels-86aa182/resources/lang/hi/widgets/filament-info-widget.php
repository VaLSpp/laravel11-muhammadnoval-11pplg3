<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'प्रलेखन',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];

<?php

return [

    'title' => 'Ver :label',

    'breadcrumb' => 'Ver',

    'content' => [

        'tab' => [
            'label' => 'Ver',
        ],

    ],

];

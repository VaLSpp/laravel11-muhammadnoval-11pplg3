<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Sign out',
        ],

    ],

    'welcome' => 'Welcome',

];

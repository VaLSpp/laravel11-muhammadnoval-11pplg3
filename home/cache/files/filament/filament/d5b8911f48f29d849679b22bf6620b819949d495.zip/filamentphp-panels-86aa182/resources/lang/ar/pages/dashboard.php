<?php

return [

    'title' => 'لوحة التحكم',

    'actions' => [

        'filter' => [

            'label' => 'تصفية',

            'modal' => [

                'heading' => 'تصفية',

                'actions' => [

                    'apply' => [

                        'label' => 'تطبيق',

                    ],

                ],

            ],

        ],

    ],

];

<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => '도큐먼트',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];

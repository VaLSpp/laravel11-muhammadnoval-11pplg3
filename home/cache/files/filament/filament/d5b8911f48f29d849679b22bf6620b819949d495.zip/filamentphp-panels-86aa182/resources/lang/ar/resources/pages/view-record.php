<?php

return [

    'title' => 'عرض :label',

    'breadcrumb' => 'عرض',

    'content' => [

        'tab' => [
            'label' => 'عرض',
        ],

    ],

];

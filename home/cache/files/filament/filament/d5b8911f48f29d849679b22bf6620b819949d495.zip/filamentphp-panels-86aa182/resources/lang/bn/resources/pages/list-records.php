<?php

return [

    'breadcrumb' => 'তালিকা',

];

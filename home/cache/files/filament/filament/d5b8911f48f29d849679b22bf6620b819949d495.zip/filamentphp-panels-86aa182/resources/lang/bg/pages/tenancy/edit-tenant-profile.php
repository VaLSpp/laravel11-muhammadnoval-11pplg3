<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Запази',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Запазено',
        ],

    ],

];

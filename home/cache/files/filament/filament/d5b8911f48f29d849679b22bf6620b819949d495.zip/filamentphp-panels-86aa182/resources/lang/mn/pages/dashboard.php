<?php

return [

    'title' => 'Хяналтын самбар',

    'actions' => [

        'filter' => [

            'label' => 'Шүүлтүүр',

            'modal' => [

                'heading' => 'Шүүлтүүр',

                'actions' => [

                    'apply' => [

                        'label' => 'Батлах',

                    ],

                ],

            ],

        ],

    ],

];

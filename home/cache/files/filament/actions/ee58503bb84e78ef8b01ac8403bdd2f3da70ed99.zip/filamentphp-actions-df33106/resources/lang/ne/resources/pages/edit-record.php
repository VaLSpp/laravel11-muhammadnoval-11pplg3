<?php

return [

    'title' => 'सम्पादन गर्नुहोस् :label',

    'breadcrumb' => 'सम्पादन गर्नुहोस्',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'रद्द गर्नुहोस्',
            ],

            'save' => [
                'label' => 'परिवर्तनहरू सुरक्षित गर्नुहोस',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'सम्पादन गर्नुहोस्',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'सुरक्षित गरियो',
        ],

    ],

];

<?php

return [

    'single' => [

        'label' => 'תצוגה',

        'modal' => [

            'heading' => 'מציג :label',

            'actions' => [

                'close' => [
                    'label' => 'סגור',
                ],

            ],

        ],

    ],

];

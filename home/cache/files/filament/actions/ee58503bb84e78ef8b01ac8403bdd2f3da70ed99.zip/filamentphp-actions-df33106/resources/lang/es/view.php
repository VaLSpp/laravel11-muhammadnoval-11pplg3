<?php

return [

    'single' => [

        'label' => 'Vista',

        'modal' => [

            'heading' => 'Vista de :label',

            'actions' => [

                'close' => [
                    'label' => 'Cerrar',
                ],

            ],

        ],

    ],

];

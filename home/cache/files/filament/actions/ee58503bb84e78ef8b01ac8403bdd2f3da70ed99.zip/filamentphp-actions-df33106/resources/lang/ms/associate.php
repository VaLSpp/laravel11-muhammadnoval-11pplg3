<?php

return [

    'single' => [

        'label' => 'Kaitkan',

        'modal' => [

            'heading' => 'Kaitkan :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rekod',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Kaitkan',
                ],

                'associate_another' => [
                    'label' => 'Kaitkan & kaitan yang lain',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Berkaitan',
            ],

        ],

    ],

];

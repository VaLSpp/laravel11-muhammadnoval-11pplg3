<?php

return [

    'single' => [

        'label' => 'Buat',

        'modal' => [

            'heading' => 'Buat :label',

            'actions' => [

                'create' => [
                    'label' => 'Buat',
                ],

                'create_another' => [
                    'label' => 'Buat & buat lainnya',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Data berhasil dibuat',
            ],

        ],

    ],

];

<?php

return [

    'single' => [

        'label' => '보기',

        'modal' => [

            'heading' => ':label 보기',

            'actions' => [

                'close' => [
                    'label' => '닫기',
                ],

            ],

        ],

    ],

];

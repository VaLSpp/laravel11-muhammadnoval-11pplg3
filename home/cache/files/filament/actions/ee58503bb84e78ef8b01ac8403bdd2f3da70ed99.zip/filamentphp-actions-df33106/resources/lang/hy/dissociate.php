<?php

return [

    'single' => [

        'label' => 'Տարանջատել',

        'modal' => [

            'heading' => 'Տարանջատել :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Տարանջատել',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Տարանջատվել է',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Տարանջատել ընտրվածը',

        'modal' => [

            'heading' => 'Տարանջատել ընտրված :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Տարանջատել ընտրվածը',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Տարանջատվել է',
            ],

        ],

    ],

];

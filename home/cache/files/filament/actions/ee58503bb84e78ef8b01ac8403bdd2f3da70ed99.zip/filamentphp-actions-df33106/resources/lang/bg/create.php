<?php

return [

    'single' => [

        'label' => 'Създай :label',

        'modal' => [

            'heading' => 'Създаване на :label',

            'actions' => [

                'create' => [
                    'label' => 'Създай',
                ],

                'create_another' => [
                    'label' => 'Създай и създай друг',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Създаден',
            ],

        ],

    ],

];

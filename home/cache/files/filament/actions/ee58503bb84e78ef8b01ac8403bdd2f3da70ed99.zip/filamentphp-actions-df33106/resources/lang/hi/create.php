<?php

return [

    'single' => [

        'label' => 'बनाएँ',

        'modal' => [

            'heading' => ':label बनाएँ',

            'actions' => [

                'create' => [
                    'label' => 'बनाएँ',
                ],

                'create_another' => [
                    'label' => 'बनाएँ और एक और एक और बनाएँ',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'बन गया',
            ],

        ],

    ],

];

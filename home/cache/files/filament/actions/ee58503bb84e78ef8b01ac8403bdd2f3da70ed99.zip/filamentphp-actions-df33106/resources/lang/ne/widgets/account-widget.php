<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'साइन आउट गर्नुहोस्',
        ],

    ],

    'welcome' => 'स्वागत छ',

];

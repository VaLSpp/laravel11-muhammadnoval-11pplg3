<?php

return [

    'trigger' => [
        'label' => '작업',
    ],

];

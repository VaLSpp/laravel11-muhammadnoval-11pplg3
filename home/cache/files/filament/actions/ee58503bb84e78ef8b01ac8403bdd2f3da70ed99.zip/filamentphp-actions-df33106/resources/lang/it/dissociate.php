<?php

return [

    'single' => [

        'label' => 'Dissocia',

        'modal' => [

            'heading' => 'Dissocia :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocia',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissociato',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dissocia selezionati',

        'modal' => [

            'heading' => 'Dissocia :label selezionati',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocia',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissociati',
            ],

        ],

    ],

];

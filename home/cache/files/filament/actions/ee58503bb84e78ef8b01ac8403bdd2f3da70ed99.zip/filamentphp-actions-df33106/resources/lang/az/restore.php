<?php

return [

    'single' => [

        'label' => 'Bərpa et',

        'modal' => [

            'heading' => ':label bərpa et',

            'actions' => [

                'restore' => [
                    'label' => 'Bərpa et',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Məlumat bərpa edildi',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Seçilənləri bərpa et',

        'modal' => [

            'heading' => ':label seçilənləri bərpa et',

            'actions' => [

                'restore' => [
                    'label' => 'Bərpa et',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Məlumatlar bərpa edildi',
            ],

        ],

    ],

];

<?php

return [

    'single' => [

        'label' => 'သီးခြား',

        'modal' => [

            'heading' => ':label သီးခြား',

            'actions' => [

                'dissociate' => [
                    'label' => 'သီးခြား',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'သိမ်းဆည်းပြီး',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dissociate selected',

        'modal' => [

            'heading' => 'Dissociate selected :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociate selected',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissociated',
            ],

        ],

    ],

];

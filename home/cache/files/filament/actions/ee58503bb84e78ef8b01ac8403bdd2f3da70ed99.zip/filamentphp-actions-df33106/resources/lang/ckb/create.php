<?php

return [

    'single' => [

        'label' => 'دروستکردنی :label',

        'modal' => [

            'heading' => ':دروستکردنی :label',

            'actions' => [

                'create' => [
                    'label' => 'دروستکرن',
                ],

                'create_another' => [
                    'label' => 'دروستکردن و تۆمارێکی تر',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'دروستکرا',
            ],

        ],

    ],

];

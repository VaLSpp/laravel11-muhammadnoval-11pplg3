<?php

return [

    'single' => [

        'label' => '수정',

        'modal' => [

            'heading' => ':label 수정',

            'actions' => [

                'save' => [
                    'label' => '저장',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => '저장 완료',
            ],

        ],

    ],

];

<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Yopish',
        ],

    ],

];

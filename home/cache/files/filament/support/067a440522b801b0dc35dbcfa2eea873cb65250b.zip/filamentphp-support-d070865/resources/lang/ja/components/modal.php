<?php

return [

    'actions' => [

        'close' => [
            'label' => '閉じる',
        ],

    ],

];

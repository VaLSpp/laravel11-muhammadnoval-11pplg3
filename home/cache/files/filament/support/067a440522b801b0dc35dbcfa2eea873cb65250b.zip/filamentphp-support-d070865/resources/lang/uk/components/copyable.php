<?php

return [

    'messages' => [
        'copied' => 'Скопійовано',
    ],

];

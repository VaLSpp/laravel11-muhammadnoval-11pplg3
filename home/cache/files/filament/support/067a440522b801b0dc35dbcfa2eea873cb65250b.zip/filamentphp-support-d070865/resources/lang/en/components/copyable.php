<?php

return [

    'messages' => [
        'copied' => 'Copied',
    ],

];

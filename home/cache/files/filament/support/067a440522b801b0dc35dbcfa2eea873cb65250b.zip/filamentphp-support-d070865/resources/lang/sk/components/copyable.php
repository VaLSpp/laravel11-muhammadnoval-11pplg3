<?php

return [

    'messages' => [
        'copied' => 'Skopírované',
    ],

];

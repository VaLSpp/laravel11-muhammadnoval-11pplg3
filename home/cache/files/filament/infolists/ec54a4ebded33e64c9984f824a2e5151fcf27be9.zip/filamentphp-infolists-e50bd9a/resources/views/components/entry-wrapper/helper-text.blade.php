<div
    {{ $attributes->class(['fi-in-entry-wrp-helper-text break-words text-sm text-gray-500']) }}
>
    {{ $slot }}
</div>
